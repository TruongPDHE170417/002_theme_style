package com.truongpd11.a001viewdesign;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner spinner;

    EditText edtEmailOrPhone;
    EditText edtPassword;
    Button btnLogin;
    static final String DEFAULT_PASSWORD = "12345";
    static final String DEFAULT_USERNAME = "admin";

    ArrayAdapter<CharSequence> adapter;

    private void onBinding() {
        spinner = (Spinner) findViewById(R.id.spinnerLang);
        adapter = ArrayAdapter.createFromResource(
                MainActivity.this,
                R.array.languages_array,
                R.layout.lang_spinner_item
        );
        edtEmailOrPhone = findViewById(R.id.edtEmailOrPhone);
        edtPassword = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnLogin);
    }

    private void onStyle() {
        spinner.setBackgroundResource(R.drawable.spinner_dropdown_cust);
    }

    private void onAction() {
        spinner.setOnItemSelectedListener(MainActivity.this);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        btnLogin.setOnClickListener(this::login);
    }

    private void login(View view) {
        String userName = getUserName();
        String password = getPassword();
        if (userName.equals(DEFAULT_USERNAME) && password.equals(DEFAULT_PASSWORD)) {
            Toast.makeText(this, "Login successfully", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Login fail", Toast.LENGTH_LONG).show();
        }
    }

    private String getPassword() {
        return edtPassword.getText().toString();
    }

    private String getUserName() {
        return edtEmailOrPhone.getText().toString();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        onBinding();
        onStyle();
        onAction();
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        //do nothing
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // do nothing
    }
}